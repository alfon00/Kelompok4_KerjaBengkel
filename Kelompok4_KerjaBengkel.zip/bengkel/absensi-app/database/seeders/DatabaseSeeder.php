<?php

namespace Database\Seeders;

use App\Models\Position;
use App\Models\Role;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // Pastikan posisi Operator selalu ada
        \App\Models\Position::firstOrCreate(['name' => 'Operator']);

        $this->call(RoleSeeder::class);
        $this->call(PositionSeeder::class);

        // Ambil ulang setelah seeder dijalankan
        $adminRoleId = \App\Models\Role::where('name', 'admin')->first()?->id;
        $operatorPositionId = \App\Models\Position::where('name', 'Operator')->first()?->id;

        if ($adminRoleId && $operatorPositionId) {
            \App\Models\User::factory()->create([
                'name' => 'Muhammad Pauzi (Admin)',
                'email' => 'admin@gmail.com',
                'password' => bcrypt('password'),
                'role_id' => $adminRoleId,
                'position_id' => $operatorPositionId,
            ]);
        }
        \App\Models\User::factory(1)->create([
            'role_id' => Role::where('name', 'operator')->first('id'),
            'position_id' => Position::where('name', 'Operator')->first('id'),
        ]);
        \App\Models\User::factory(10)->create([
            'role_id' => Role::where('name', 'user')->first('id'), // user === employee
            'position_id' => Position::select('id')->inRandomOrder()->first()->id
        ]);
    }
}
