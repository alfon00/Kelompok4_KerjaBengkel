

<?php $__env->startPush('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/auth/login.css')); ?>">
<style>
    body {
        background: linear-gradient(135deg, #e0eafc 0%, #cfdef3 100%);
        min-height: 100vh;
        font-family: 'Poppins', sans-serif;
    }
    .login-glass {
        background: rgba(255,255,255,0.96);
        border-radius: 20px;
        box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.10);
        padding: 2.5rem 2rem 2rem 2rem;
        max-width: 410px;
        margin: 70px auto;
        position: relative;
        overflow: hidden;
        animation: fadeIn 1s;
        border: 1.5px solid #e0eafc;
        backdrop-filter: blur(8px);
    }
    .login-glass h1 {
        font-weight: 800;
        color: #6a82fb;
        margin-bottom: 1.2rem;
        letter-spacing: 1px;
        text-shadow: 0 2px 8px #e0eafc55;
    }
    .login-glass .form-floating label {
        color: #7f9cf5;
        font-weight: 500;
    }
    .login-glass .form-control {
        border-radius: 12px;
        border: 1.5px solid #b6c6e6;
        margin-bottom: 1rem;
        background: rgba(255,255,255,0.85);
        font-size: 1.08rem;
    }
    .login-glass .btn-primary {
        background: linear-gradient(90deg, #a8edea 0%, #fed6e3 100%);
        color: #3a3a3a;
        border: none;
        border-radius: 12px;
        font-weight: 700;
        box-shadow: 0 2px 8px rgba(106,130,251,0.10);
        transition: background 0.3s, transform 0.2s;
    }
    .login-glass .btn-primary:hover {
        background: linear-gradient(90deg, #fed6e3 0%, #a8edea 100%);
        color: #222;
        transform: scale(1.03);
    }
    .login-glass .form-check-label {
        color: #555;
    }
    .login-glass .text-muted {
        color: #aaa !important;
    }
    .login-glass .login-icon {
        display: flex;
        justify-content: center;
        margin-bottom: 1.2rem;
    }
    .login-glass .login-icon img {
        width: 62px;
        height: 62px;
        filter: drop-shadow(0 2px 8px #a8edea88);
    }
    @keyframes  fadeIn {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="login-glass">
    <div class="login-icon">
        <img src="https://img.icons8.com/color/96/000000/fingerprint-scan.png" alt="Login Icon">
    </div>
    <form method="POST" action="<?php echo e(route('auth.login')); ?>" id="login-form">
        <h1 class="mb-2 text-center">Selamat Datang 👋</h1>
        <p class="mb-4 text-center text-muted">Silakan masuk untuk absensi</p>
        <div class="form-floating mb-3">
            <input type="email" class="form-control" id="floatingInputEmail" name="email" placeholder="name@example.com" required autofocus>
            <label for="floatingInputEmail">Email address</label>
        </div>
        <div class="form-floating mb-3">
            <input type="password" class="form-control" id="floatingPassword" name="password" placeholder="Password" required>
            <label for="floatingPassword">Password</label>
        </div>
        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" name="remember" id="flexCheckRemember">
            <label class="form-check-label" for="flexCheckRemember">
                Ingatkan Saya di Perangkat ini
            </label>
        </div>
        <button class="w-100 btn btn-primary mb-2" type="submit" id="login-form-button">Masuk</button>
        <p class="mt-4 mb-0 text-center text-muted" style="font-size: 0.95rem">&copy; <?php echo e(date('Y')); ?> Absensi App</p>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script type="module" src="<?php echo e(asset('js/auth/login.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\M.J.NGUI\Desktop\bengkel\absensi-app\resources\views/auth/login.blade.php ENDPATH**/ ?>