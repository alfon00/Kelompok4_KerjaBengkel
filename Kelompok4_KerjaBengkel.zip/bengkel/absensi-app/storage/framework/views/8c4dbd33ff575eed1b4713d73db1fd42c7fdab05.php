

<?php $__env->startPush('style'); ?>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<style>
    body { font-family: 'Poppins', sans-serif; background: linear-gradient(120deg, #e0eafc 0%, #cfdef3 100%); }
    .dashboard-header {
        font-weight: 700;
        color: #7f9cf5;
        margin-bottom: 2rem;
        letter-spacing: 1px;
    }
    .dashboard-cards {
        gap: 2rem;
    }
    .dashboard-card {
        border-radius: 24px;
        box-shadow: 0 6px 24px 0 rgba(127, 156, 245, 0.08);
        background: linear-gradient(135deg, #e0eafc 0%, #f6f1f1 60%, #cfdef3 100%);
        transition: transform 0.2s, box-shadow 0.2s;
        border: none;
        backdrop-filter: blur(10px);
        position: relative;
        overflow: hidden;
        border: 1.5px solid #e3e8f0;
    }
    .dashboard-card:hover {
        transform: translateY(-6px) scale(1.03);
        box-shadow: 0 12px 32px 0 rgba(127,156,245,0.13);
    }
    .dashboard-card .card-body {
        padding: 2.2rem 1.5rem 1.7rem 1.5rem;
        text-align: center;
    }
    .dashboard-card h6 {
        color: #8bbabb;
        font-size: 1.1rem;
        margin-bottom: 0.5rem;
        font-weight: 600;
    }
    .dashboard-card h4 {
        font-size: 2.2rem;
        color: #7f9cf5;
        margin-bottom: 0.2rem;
        font-weight: 700;
        text-shadow: 0 1px 2px #e0eafc;
    }
    .dashboard-card .dashboard-icon {
        font-size: 2.5rem;
        margin-bottom: 0.7rem;
        color: #a8edea;
        display: flex;
        justify-content: center;
        filter: drop-shadow(0 2px 6px #cfdef3);
    }
    @media (max-width: 768px) {
        .dashboard-cards {
            flex-direction: column;
            gap: 1rem;
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div>
    <h2 class="dashboard-header">Dashboard</h2>
    <div class="row dashboard-cards d-flex">
        <div class="col-md-3 col-12 mb-4">
            <div class="card dashboard-card">
                <div class="card-body">
                    <div class="dashboard-icon">
                        <img src="https://img.icons8.com/color/48/briefcase--v1.png" width="38" height="38" alt="Jabatan">
                    </div>
                    <h6>Data Jabatan</h6>
                    <h4><?php echo e($positionCount); ?></h4>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-12 mb-4">
            <div class="card dashboard-card">
                <div class="card-body">
                    <div class="dashboard-icon">
                        <img src="https://img.icons8.com/color/48/conference-call--v2.png" width="38" height="38" alt="Karyawan">
                    </div>
                    <h6>Data Karyawan</h6>
                    <h4><?php echo e($userCount); ?></h4>
                </div>
            </div>
        </div>
        <!-- Tambahkan card lain di sini jika diperlukan -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\M.J.NGUI\Desktop\bengkel\absensi-app\resources\views/dashboard/index.blade.php ENDPATH**/ ?>