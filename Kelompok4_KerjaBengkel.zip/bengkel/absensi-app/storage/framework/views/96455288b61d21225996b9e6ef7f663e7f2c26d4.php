<header class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top p-0" style="backdrop-filter: blur(10px); background: linear-gradient(90deg, #e0eafc 0%, #f6f1f1 60%, #cfdef3 100%) !important; border-bottom: 1.5px solid #eaeaea;">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold text-primary d-flex align-items-center" href="/">
            <img src="https://img.icons8.com/color/48/000000/fingerprint-scan.png" alt="Logo" width="32" height="32" class="me-2">
            Absensi App
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/attendances">Absensi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/dashboard">Dashboard</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Akun
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <li>
                            <form action="<?php echo e(route('auth.logout')); ?>" method="post" class="px-3 py-1">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="dropdown-item text-danger" type="submit">Keluar</button>
                            </form>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
    <style>
        .navbar {
            border-bottom: 1.5px solid #eaeaea;
            background: linear-gradient(90deg, #e0eafc 0%, #f6f1f1 60%, #cfdef3 100%) !important;
            backdrop-filter: blur(10px);
        }
        .navbar-brand {
            font-size: 1.3rem;
            letter-spacing: 1px;
        }
        .navbar-nav .nav-link {
            color: #7f9cf5 !important;
            font-weight: 500;
            margin-right: 0.5rem;
            transition: color 0.2s, background 0.2s, border-radius 0.2s;
            border-radius: 8px;
            padding: 0.4rem 1rem;
        }
        .navbar-nav .nav-link.active, .navbar-nav .nav-link:hover {
            color: #6a82fb !important;
            background: #e0eafc;
        }
        .navbar .dropdown-menu {
            min-width: 120px;
            border-radius: 12px;
            box-shadow: 0 4px 16px 0 rgba(127,156,245,0.08);
            background: #f6f1f1;
        }
        .navbar .dropdown-item.text-danger {
            color: #f67280 !important;
        }
    </style>
</header><?php /**PATH C:\Users\M.J.NGUI\Desktop\bengkel\absensi-app\resources\views/partials/navbar.blade.php ENDPATH**/ ?>